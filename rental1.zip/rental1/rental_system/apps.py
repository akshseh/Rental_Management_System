from django.apps import AppConfig


class RentalSystemConfig(AppConfig):
    name = 'rental_system'
